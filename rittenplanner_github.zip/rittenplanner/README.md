# 🚐 RittenPlanner — De Jonge Wereld

Schoolritten beheer voor De Jonge Wereld, gemeente Westerkwartier.

## Gebruik

Open de app via: `https://[jouw-gebruikersnaam].github.io/rittenplanner`

## Functies

- 📥 Excel rapport importeren (dagrapport uit het systeem)
- 📋 Automatische rittenindeling per dag
- 👤 Chauffeurs en begeleiders toewijzen
- ⚽ Vaste sportactiviteiten beheren
- 📄 Data exporteren voor PDF generatie

## Installatie op GitHub Pages

### Stap 1: GitHub account
Ga naar [github.com](https://github.com) en maak een gratis account aan.

### Stap 2: Nieuwe repository aanmaken
1. Klik op de groene knop **New** (of **+** rechtsboven)
2. Geef de repository de naam: `rittenplanner`
3. Zet hem op **Public**
4. Klik **Create repository**

### Stap 3: Bestanden uploaden
1. Klik op **uploading an existing file**
2. Sleep ALLE bestanden en mappen uit deze zip naar het uploadvenster
3. Klik **Commit changes**

### Stap 4: GitHub Pages aanzetten
1. Ga naar **Settings** → **Pages**
2. Bij **Source**: kies **GitHub Actions**
3. Wacht 2-3 minuten
4. Je app is live op: `https://[gebruikersnaam].github.io/rittenplanner`

### Stap 5: Delen met collega's
Stuur de link door — collega's openen hem gewoon in de browser, geen installatie nodig!

## Lokaal draaien (voor ontwikkelaars)

```bash
npm install
npm run dev
```
