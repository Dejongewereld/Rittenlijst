import { useState, useRef } from "react";
import * as XLSX from "xlsx";

// ── Constanten ────────────────────────────────────────────────────────────────
const DAYS = ["Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag"];
const BUS_CAP = 8;

const LOCATIES = {
  WL:{naam:"Waezenburglaan",adres:"Waezenburglaan 49, 9351 HB Leek",kleur:"#ffffff",tekstKleur:"#111827",border:"#9ca3af"},
  SL:{naam:"Rodenburg",adres:"Rodenburg 1B, 9351 PV Leek",kleur:"#6b7280",tekstKleur:"#ffffff",border:"#4b5563"},
  OL:{naam:"de Knip",adres:"De Knip 2, 9351 XZ Leek",kleur:"#16a34a",tekstKleur:"#ffffff",border:"#15803d"},
};

const BSO_LOC = {"ActiviteitenBSO":"WL","OutdoorBSO":"OL","Sport BSO":"SL"};

const AFKORT = {
  "Basisschool De Beelen":"Beelen","Basisschool De Flint":"De Flint",
  "Basisschool De Stapsteen":"Stapsteen","CBS Van Panhuys":"Panhuys",
  "Christelijke Basisschool De Springplank":"Springplank",
  "Christelijke Nationale Basisschool De Regenboog":"Regenboog",
  "De Nijenoert":"Nijenoert","Katholieke Basisschool De Hasselbraam":"Hasselbraam",
  "Jenaplanschool 't Sterrenpad":"Sterrenpad","Samenwerkingsschool de Klimboom":"Klimboom",
};

const STD_VERVOER = [
  {school:"Stapsteen",loc:"SL",v:"lopen"},{school:"Stapsteen",loc:"WL",v:"lopen"},
  {school:"Nijenoert",loc:"SL",v:"lopen"},{school:"Nijenoert",loc:"WL",v:"lopen"},
  {school:"Springplank",loc:"SL",v:"lopen"},{school:"Panhuys",loc:"OL",v:"lopen"},
  {school:"Hasselbraam",loc:"OL",v:"lopen"},{school:"Stapsteen",loc:"OL",v:"fiets"},
  {school:"Nijenoert",loc:"OL",v:"fiets"},{school:"Regenboog",loc:"OL",v:"fiets"},
  {school:"Beelen",loc:"OL",v:"fiets"},{school:"Springplank",loc:"OL",v:"fiets"},
];

const VASTE_RITTEN = [
  {id:"kg",label:"Kiss & Go → Springplank",kleur:"#ea580c",opmerking:"Kinderen afzetten op locatie en doorrijden naar Springplank",
   stops:[{tijd:"14:00",scholen:["Panhuys","Hasselbraam"],filter:k=>k.loc==="WL"},{tijd:"14:30",scholen:["Springplank"],filter:k=>true}]},
  {id:"be",label:"Beelen → Sterrenpad",kleur:"#2563eb",opmerking:"Kinderen afzetten op locatie en doorrijden naar Sterrenpad",
   stops:[{tijd:"14:00",scholen:["Beelen"],filter:k=>true},{tijd:"14:30",scholen:["Sterrenpad"],filter:k=>true}]},
  {id:"fl",label:"De Flint → Regenboog",kleur:"#7c3aed",opmerking:"Kinderen afzetten op locatie en doorrijden naar Regenboog",
   stops:[{tijd:"14:00",scholen:["De Flint"],filter:k=>true},{tijd:"14:30",scholen:["Regenboog"],filter:k=>true}]},
  {id:"nj",label:"Nijenoert",kleur:"#0891b2",opmerking:null,
   stops:[{tijd:"14:00",scholen:["Nijenoert"],filter:k=>true}]},
  {id:"kb",label:"Klimboom",kleur:"#065f46",opmerking:"Doorrijden naar ... (per dag invullen)",
   stops:[{tijd:"14:00",scholen:["Klimboom"],filter:k=>true}]},
];

const V_LABEL = {bus:"Bus",lopen:"Lopen",fiets:"Fiets",zelf:"Zelf"};

function kortNaam(n) {
  const d = n.trim().split(/\s+/);
  if (d.length === 1) return d[0];
  return d[0] + " " + d[d.length-1][0].toUpperCase() + ".";
}

// ── Excel parser ──────────────────────────────────────────────────────────────
function parseXLSX(wb) {
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(sheet, {header:1, defval:""});
  const kids = []; let bso = "", school = "";
  for (const row of rows) {
    const c0=String(row[0]||"").trim(), c1=String(row[1]||"").trim(), c3=String(row[3]||"").trim();
    if (c0.includes(" - ")&&!c1&&!c0.toLowerCase().includes("totaal")) {
      const[b,...sp]=c0.split(" - "); bso=b.trim(); school=sp.join(" - ").trim(); continue;
    }
    if (c0==="Nr."||c1==="Naam") continue;
    const nr = parseInt(c0);
    if (!isNaN(nr)&&nr>0&&c1) {
      const locEntry = Object.entries(BSO_LOC).find(([k])=>bso.startsWith(k));
      const loc = locEntry?locEntry[1]:"?";
      const afk = AFKORT[school]||school;
      const std = STD_VERVOER.find(r=>r.school===afk&&r.loc===loc);
      const tijdOverride = ["Regenboog","Springplank"].includes(afk)?"14:30":null;
      kids.push({id:Math.random(),naam:c1,school,afk,loc,tijd:tijdOverride||c3||"14:00",vervoer:std?std.v:"bus"});
    }
  }
  return kids;
}

// ── Rittenlogica ──────────────────────────────────────────────────────────────
function buildRitten(busKids) {
  const gebruikt = new Set();
  const ritten = [];

  // Vaste ritten
  for (const def of VASTE_RITTEN) {
    const stopKids = def.stops.map(s=>({...s, gevonden:busKids.filter(k=>s.scholen.includes(k.afk)&&s.filter(k)&&!gebruikt.has(k.id))}));
    const alle = stopKids.flatMap(s=>s.gevonden);
    if (!alle.length) continue;
    const nBussen = Math.max(...stopKids.map(s=>Math.ceil(s.gevonden.length/BUS_CAP)||0), 1);
    for (let b=0; b<nBussen; b++) {
      const stops=[], kinderen=[];
      stopKids.forEach(({tijd,scholen,gevonden})=>{
        const lading = gevonden.slice(b*BUS_CAP,(b+1)*BUS_CAP);
        if (!lading.length) return;
        lading.forEach(k=>gebruikt.add(k.id));
        kinderen.push(...lading);
        stops.push({tijd,scholen,kids:lading});
      });
      if (!stops.length) continue;
      if (b===0) ritten.push({id:def.id+"_1",label:def.label,kleur:def.kleur,opmerking:def.opmerking,stops,kinderen});
      else stops.flatMap(s=>s.kids).forEach(k=>gebruikt.delete(k.id));
    }
  }

  // Panhuys + Hasselbraam + Regenboog overloop
  const phVrij = busKids.filter(k=>["Panhuys","Hasselbraam"].includes(k.afk)&&!gebruikt.has(k.id));
  const regVrij = busKids.filter(k=>k.afk==="Regenboog"&&!gebruikt.has(k.id));
  let regIdx = 0;
  const nPhBussen = Math.max(Math.ceil(phVrij.length/BUS_CAP), regVrij.length>0?1:0);
  for (let b=0; b<nPhBussen; b++) {
    const phLading = phVrij.slice(b*BUS_CAP,(b+1)*BUS_CAP);
    const stops = [];
    if (phLading.length) { phLading.forEach(k=>gebruikt.add(k.id)); stops.push({tijd:"14:00",scholen:["Panhuys","Hasselbraam"],kids:phLading}); }
    const regLading = regVrij.slice(regIdx,regIdx+BUS_CAP);
    if (regLading.length) { regLading.forEach(k=>gebruikt.add(k.id)); stops.push({tijd:"14:30",scholen:["Regenboog"],kids:regLading}); regIdx+=regLading.length; }
    if (!stops.length) break;
    const heeftReg = stops.some(s=>s.scholen.includes("Regenboog"));
    ritten.push({id:"ph_"+(b+1),label:heeftReg?"Panhuys + Hasselbraam → Regenboog":"Panhuys + Hasselbraam",
      kleur:"#0369a1",opmerking:heeftReg?"Kinderen afzetten op locatie en doorrijden naar Regenboog":null,
      stops,kinderen:stops.flatMap(s=>s.kids)});
  }
  while (regIdx<regVrij.length) {
    const lading=regVrij.slice(regIdx,regIdx+BUS_CAP);
    lading.forEach(k=>gebruikt.add(k.id));
    ritten.push({id:"reg_"+(regIdx+1),label:"Regenboog (extra)",kleur:"#0369a1",opmerking:null,
      stops:[{tijd:"14:30",scholen:["Regenboog"],kids:lading}],kinderen:lading});
    regIdx+=lading.length;
  }

  // Vrije buskids
  const vrij = busKids.filter(k=>!gebruikt.has(k.id));
  if (vrij.length) {
    const per14={}, per1430={};
    vrij.forEach(k=>{ if(k.tijd==="14:00"){if(!per14[k.afk])per14[k.afk]=[];per14[k.afk].push(k);} else{if(!per1430[k.afk])per1430[k.afk]=[];per1430[k.afk].push(k);} });
    const sorted1430=Object.entries(per1430).sort((a,b)=>b[1].length-a[1].length);
    const gekoppeld=new Set();
    const ladingen14=[];
    Object.entries(per14).forEach(([school,sk])=>{ for(let i=0;i<sk.length;i+=BUS_CAP) ladingen14.push({school,kids:sk.slice(i,i+BUS_CAP)}); });
    let nr=ritten.length+1;
    for (const lading of ladingen14) {
      lading.kids.forEach(k=>gebruikt.add(k.id));
      const stops=[{tijd:"14:00",scholen:[lading.school],kids:lading.kids}];
      const koppel=sorted1430.find(([s])=>!gekoppeld.has(s));
      if (koppel) { const[s,k]=koppel; const mee=k.slice(0,BUS_CAP); mee.forEach(x=>gebruikt.add(x.id)); stops.push({tijd:"14:30",scholen:[s],kids:mee}); if(k.length<=BUS_CAP)gekoppeld.add(s); }
      ritten.push({id:"b"+nr,label:"Bus "+nr,kleur:"#374151",opmerking:null,stops,kinderen:stops.flatMap(s=>s.kids)}); nr++;
    }
    sorted1430.forEach(([s,k])=>{ if(gekoppeld.has(s))return; const nog=k.filter(x=>!gebruikt.has(x.id)); if(!nog.length)return;
      for(let i=0;i<nog.length;i+=BUS_CAP){ const l=nog.slice(i,i+BUS_CAP); l.forEach(x=>gebruikt.add(x.id));
        ritten.push({id:"b"+nr,label:"Bus "+nr,kleur:"#374151",opmerking:null,stops:[{tijd:"14:30",scholen:[s],kids:l}],kinderen:l}); nr++; } });
  }
  return ritten;
}

// Samenvoegen
function buildEffectief(ritten, samengevoegd, dag) {
  const samen=samengevoegd[dag]||{};
  const res=[], verwerkt=new Set();
  for (const rit of ritten) {
    if (verwerkt.has(rit.id)) continue;
    const gekoppeld=ritten.filter(r=>samen[r.id]===rit.id&&!verwerkt.has(r.id));
    if (gekoppeld.length) {
      const alleStops=rit.stops.map(s=>({...s,kids:[...s.kids],scholen:[...s.scholen]}));
      const alleKind=[...rit.kinderen];
      gekoppeld.forEach(r=>{ r.stops.forEach(s=>{ const b=alleStops.find(as=>as.tijd===s.tijd);
        if(b){b.scholen=[...new Set([...b.scholen,...s.scholen])];b.kids=[...b.kids,...s.kids];}
        else alleStops.push({...s,kids:[...s.kids],scholen:[...s.scholen]}); });
        alleKind.push(...r.kinderen); verwerkt.add(r.id); });
      alleStops.sort((a,b)=>a.tijd.localeCompare(b.tijd));
      res.push({...rit,stops:alleStops,kinderen:alleKind,samengevoegdLabel:gekoppeld.map(r=>r.label).join(" + ")});
    } else if (!samen[rit.id]) res.push(rit);
    verwerkt.add(rit.id);
  }
  return res;
}

// Lopers & fietsers
function buildGroepen(kids) {
  const lopers={}, fietsers={};
  kids.filter(k=>["lopen","fiets","zelf"].includes(k.vervoer)).forEach(k=>{
    if (k.vervoer==="lopen") {
      const groep=["Panhuys","Hasselbraam"].includes(k.afk)?"Panhuys + Hasselbraam":k.afk;
      const gId="L_"+groep;
      const opm=groep==="Nijenoert"?"WL-kinderen afzetten bij WL (lopen langs de WL locatie)":null;
      if (!lopers[gId]) lopers[gId]={id:gId,label:groep,type:"lopen",kleur:"#111827",kids:[],opmerking:opm};
      lopers[gId].kids.push(k);
    } else {
      const gId=["Nijenoert","Regenboog"].includes(k.afk)?"F_r1":["Stapsteen","Springplank"].includes(k.afk)?"F_r2":"F_"+k.afk;
      const label=gId==="F_r1"?"Nijenoert → Regenboog":gId==="F_r2"?"Stapsteen → Springplank":k.afk;
      if (!fietsers[gId]) fietsers[gId]={id:gId,label,type:"fiets",kleur:"#dc2626",kids:[]};
      fietsers[gId].kids.push(k);
    }
  });
  return [...Object.values(lopers),...Object.values(fietsers)];
}

// ── Hoofd component ───────────────────────────────────────────────────────────
export default function App() {
  const [tab,setTab]       = useState("import");
  const [dag,setDag]       = useState(0);
  const [kdPD,setKdPD]     = useState({});
  const [pers,setPers]     = useState([
    {id:1,naam:"Jaap"},{id:2,naam:"Roos"},{id:3,naam:"Wim"},{id:4,naam:"Wendy"},
    {id:5,naam:"Marc"},{id:6,naam:"Joyce"},{id:7,naam:"Sem"},{id:8,naam:"Nikita"},
    {id:9,naam:"Janine"},{id:10,naam:"Natascha"},{id:11,naam:"Marijke"},{id:12,naam:"Nynke"},
    {id:13,naam:"Ilse B."},{id:14,naam:"Axinja"},{id:15,naam:"Zoya"},{id:16,naam:"Ziggy"},
    {id:17,naam:"Mettari"},{id:18,naam:"Sven"},
  ]);
  const [aanwezig,setAanwezig] = useState({});
  const [chauf,setChauf]       = useState({});
  const [begel,setBegel]       = useState({});
  const [begel2,setBegel2]     = useState({});
  const [actBegel,setActBegel] = useState({});
  const [samen,setSamen]       = useState({});
  const [maxBus,setMaxBus]     = useState({});
  const [bijz,setBijz]         = useState("");
  const [fietsen,setFietsen]   = useState({});
  const [impSt,setImpSt]       = useState(null);
  const [exportData,setExportData] = useState(null);
  const [nieuweNaam,setNN]     = useState("");
  const [activiteiten,setAct]  = useState([
    {id:1,naam:"Gymles",locatie:"Nijenoertzaal",vertrek:"16:00",start:"16:15",eind:"17:15",kinderen:"Chloe",opmerking:"Ophalen 17:15"},
    {id:2,naam:"Judo",locatie:"Rodenburg (SL)",vertrek:"15:45",start:"16:00",eind:"17:00",kinderen:"Bryan",opmerking:"Bryan loopt na Judo naar de SL"},
    {id:3,naam:"Zwemles",locatie:"Oostwold",vertrek:"16:30",start:"17:00",eind:"17:30",kinderen:"Emily, Pim, Eva Knoop, Isabelle",opmerking:""},
    {id:4,naam:"Dansen",locatie:"Rodenburg (SL)",vertrek:"16:00",start:"16:00",eind:"17:00",kinderen:"Tessa Kaptein, Celyne Lautenbach, Lise Kleinman",opmerking:""},
    {id:5,naam:"Voetbal VEV",locatie:"VEV",vertrek:"15:50",start:"16:00",eind:"17:00",kinderen:"Lucas Braaksma",opmerking:""},
    {id:6,naam:"Voetbal VEV",locatie:"VEV",vertrek:"16:50",start:"17:00",eind:"18:00",kinderen:"Tom Dijkema",opmerking:""},
    {id:7,naam:"Beweegacademy",locatie:"VEV",vertrek:"14:45",start:"15:00",eind:"17:00",kinderen:"Tycho Gerrits, Evan Nanninga, Max Helder, Teun Rolden, Noud Kosse, Milan A., Tijn Mollema",opmerking:"Ophalen 17:00"},
    {id:8,naam:"Ballet",locatie:"Sportcentrum",vertrek:"16:40",start:"17:00",eind:"",kinderen:"Vera, Elea",opmerking:""},
    {id:9,naam:"Survival",locatie:"Boerakker",vertrek:"16:00",start:"",eind:"",kinderen:"Alex Gerrits",opmerking:""},
    {id:10,naam:"Gitaarles",locatie:"Zelfstandig",vertrek:"16:00",start:"16:30",eind:"",kinderen:"Maurits van der Velde",opmerking:""},
    {id:11,naam:"Voetbal TLC",locatie:"TLC",vertrek:"17:20",start:"18:00",eind:"",kinderen:"Milan Eizinga, Jayden Eizinga",opmerking:""},
  ]);
  const [nieuweAct,setNieuweAct] = useState({naam:"",locatie:"",vertrek:"",start:"",eind:"",kinderen:"",opmerking:""});
  const fileRef = useRef();

  const kids    = kdPD[dag]||[];
  const maxB    = maxBus[dag]??6;
  const busKids = kids.filter(k=>k.vervoer==="bus");

  // Opvang
  const isAan     = (id,loc) => (aanwezig[dag]?.[loc]||[]).includes(id);
  const togAan    = (id,loc) => setAanwezig(p=>{const d=p[dag]||{},h=d[loc]||[];return{...p,[dag]:{...d,[loc]:h.includes(id)?h.filter(x=>x!==id):[...h,id]}};});
  const aanNamen  = loc => pers.filter(p=>(aanwezig[dag]?.[loc]||[]).includes(p.id)).map(p=>p.naam);
  const aanIds    = new Set(Object.values(aanwezig[dag]||{}).flat());
  const beschikbaar = aanIds.size>0?pers.filter(p=>aanIds.has(p.id)):pers;

  // Import
  function doImport(e) {
    const f=e.target.files[0]; if(!f) return;
    setImpSt("laden");
    const r=new FileReader();
    r.onload=ev=>{
      try{const wb=XLSX.read(ev.target.result,{type:"array"});const k=parseXLSX(wb);
        if(!k.length){setImpSt("leeg");return;}
        setKdPD(p=>({...p,[dag]:k}));setImpSt({n:k.length});setTab("ritten");
      }catch{setImpSt("fout");}
    };
    r.readAsArrayBuffer(f); e.target.value="";
  }
  const setV = (id,v) => setKdPD(p=>({...p,[dag]:(p[dag]||[]).map(k=>k.id===id?{...k,vervoer:v}:k)}));

  // Chauffeurs
  const getChauf  = id => { const pid=chauf[dag]?.[id]; return pers.find(p=>p.id===pid)||null; };
  const setChaufId= (id,pid) => setChauf(p=>({...p,[dag]:{...(p[dag]||{}),[id]:pid||null}}));
  const bezet     = id => new Set(Object.entries(chauf[dag]||{}).filter(([k])=>k!==id).map(([,v])=>v));

  // Begeleiders
  const getBegel  = id => { const pid=begel[dag]?.[id]; return pers.find(p=>p.id===pid)||null; };
  const setBegelId= (id,pid) => setBegel(p=>({...p,[dag]:{...(p[dag]||{}),[id]:pid||null}}));
  const bz1       = id => new Set(Object.entries(begel[dag]||{}).filter(([k])=>k!==id).map(([,v])=>v));
  const getBegel2 = id => { const pid=begel2[dag]?.[id]; return pers.find(p=>p.id===pid)||null; };
  const setBegelId2=(id,pid) => setBegel2(p=>({...p,[dag]:{...(p[dag]||{}),[id]:pid||null}}));
  const bz2       = id => new Set(Object.entries(begel2[dag]||{}).filter(([k])=>k!==id).map(([,v])=>v));

  // Samenvoegen
  const voegSamen    = (id1,id2) => setSamen(p=>({...p,[dag]:{...(p[dag]||{}),[id2]:id1}}));
  const maakLosSamen = id => setSamen(p=>{const d={...(p[dag]||{})};delete d[id];return{...p,[dag]:d};});

  // Ritten berekenen
  const rittenRaw = buildRitten(busKids);
  const ritten    = buildEffectief(rittenRaw, samen, dag);
  const groepen   = buildGroepen(kids);

  // Export data voor PDF generatie
  function exporteerData() {
    const data = {
      dag:DAYS[dag],
      datum:new Date().toLocaleDateString("nl-NL",{day:"numeric",month:"long",year:"numeric"}),
      bijzonderheden:bijz,
      opvangWL:aanNamen("WL").join(", "),
      opvangSL:aanNamen("SL").join(", "),
      opvangOL:aanNamen("OL").join(", "),
      fietsen:[...new Set(kids.filter(k=>["fiets","zelf"].includes(k.vervoer)).map(k=>k.afk))].sort()
        .map(s=>({school:s,rijders:kids.filter(k=>["fiets","zelf"].includes(k.vervoer)&&k.afk===s).length,aantal:fietsen[dag]?.[s]||"?"})),
      ritten:ritten.map(rit=>({
        label:rit.label, chauffeur:getChauf(rit.id)?.naam||"", kleur:rit.kleur, opmerking:rit.opmerking||"",
        stops:rit.stops.map(s=>({tijd:s.tijd,school:s.scholen.join(" + "),
          kinderen:s.kids.map(k=>({naam:kortNaam(k.naam),loc:k.loc}))}))
      })),
      lopers:groepen.filter(g=>g.type==="lopen").map(g=>({
        label:g.label,begel:getBegel(g.id)?.naam||"",begel2:getBegel2(g.id)?.naam||"",opmerking:g.opmerking||"",
        tijden:[...new Set(g.kids.map(k=>k.tijd))].sort().map(t=>({tijd:t,namen:g.kids.filter(k=>k.tijd===t).map(k=>kortNaam(k.naam)).join(", ")}))
      })),
      fietsers:groepen.filter(g=>g.type==="fiets").map(g=>({
        label:g.label,begel:getBegel(g.id)?.naam||"",
        tijden:[...new Set(g.kids.map(k=>k.tijd))].sort().map(t=>({tijd:t,namen:g.kids.filter(k=>k.tijd===t).map(k=>kortNaam(k.naam)+(k.vervoer==="zelf"?" (Z)":"")).join(", ")}))
      })),
      activiteiten:activiteiten.map(act=>{
        const brId=actBegel[dag]?.["brenger_"+act.id];
        const br=brId==="zelf"?"Zelfstandig":brId?pers.find(p=>p.id===Number(brId))?.naam||"":"";
        return{naam:act.naam,locatie:act.locatie,vertrek:act.vertrek,start:act.start,eind:act.eind,
          kinderen:act.kinderen.split(",").map(n=>kortNaam(n.trim())).join(", "),brenger:br};
      }),
    };
    return JSON.stringify(data, null, 2);
  }

  // ── Render helpers ────────────────────────────────────────────────────────
  function KindBadge({k, metKnoppen=true}) {
    const L = LOCATIES[k.loc];
    return (
      <div style={{display:"inline-flex",alignItems:"center",gap:3,
        background:k.vervoer==="zelf"?"#6b7280":L?.kleur,
        color:k.vervoer==="zelf"?"#fff":L?.tekstKleur,
        border:"1px solid "+(L?.border||"#ccc"),
        borderRadius:5,padding:"3px 7px",fontSize:12,fontWeight:"bold"}}>
        {kortNaam(k.naam)}
        {k.vervoer==="zelf"&&<span style={{fontSize:9,opacity:0.8,fontWeight:"normal"}}>(Z)</span>}
        <span style={{fontSize:9,opacity:0.7,fontWeight:"normal"}}>{k.loc}</span>
        {metKnoppen&&(
          <div style={{display:"flex",gap:1,marginLeft:2}}>
            {["bus","lopen","fiets"].map(v=>(
              <button key={v} onClick={()=>setV(k.id,v)}
                style={{padding:"0 3px",borderRadius:2,border:"none",
                  background:k.vervoer===v?"rgba(0,0,0,0.35)":"rgba(0,0,0,0.12)",
                  color:"inherit",cursor:"pointer",fontSize:8,fontFamily:"inherit"}}>
                {V_LABEL[v][0]}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  function SelectDropdown({value, onChange, opties, placeholder, stijl}) {
    return (
      <select value={value||""} onChange={e=>onChange(e.target.value?Number(e.target.value):null)}
        style={{fontSize:12,border:"1px solid #e5e7eb",borderRadius:6,padding:"3px 6px",fontFamily:"inherit",background:"#fff",...stijl}}>
        <option value="">{placeholder}</option>
        {opties.map(p=><option key={p.id} value={p.id}>{p.naam}</option>)}
      </select>
    );
  }

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div style={{minHeight:"100vh",background:"#f3f4f6",fontFamily:"system-ui,sans-serif",fontSize:14,color:"#111827"}}>

      {/* Header */}
      <div style={{background:"#1e1b4b",color:"#fff",padding:"12px 24px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:22}}>🚐</span>
          <div><div style={{fontWeight:"bold",fontSize:16}}>RittenPlanner</div><div style={{fontSize:10,opacity:0.5}}>DE JONGE WERELD — WESTERKWARTIER</div></div>
        </div>
        <div style={{display:"flex",gap:4}}>
          {[["import","📥 Import"],["ritten","📋 Ritten"],["activiteiten","⚽ Activiteiten"],["personeel","👤 Personeel"]].map(([k,l])=>(
            <button key={k} onClick={()=>setTab(k)}
              style={{background:tab===k?"#ea580c":"rgba(255,255,255,0.1)",border:"none",color:"#fff",padding:"7px 14px",borderRadius:6,cursor:"pointer",fontFamily:"inherit",fontWeight:tab===k?"bold":"normal",fontSize:13}}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Dag tabs */}
      <div style={{background:"#fff",borderBottom:"1px solid #e5e7eb",padding:"0 24px",display:"flex"}}>
        {DAYS.map((d,i)=>{const n=(kdPD[i]||[]).length;return(
          <button key={i} onClick={()=>{setDag(i);setImpSt(null);setExportData(null);}}
            style={{background:"none",border:"none",borderBottom:dag===i?"3px solid #ea580c":"3px solid transparent",
              color:dag===i?"#ea580c":"#6b7280",padding:"11px 16px",cursor:"pointer",fontFamily:"inherit",fontWeight:dag===i?"bold":"normal",fontSize:13}}>
            {d}{n>0&&<span style={{background:"#ea580c",color:"#fff",borderRadius:20,padding:"1px 6px",fontSize:10,marginLeft:4}}>{n}</span>}
          </button>
        );})}
      </div>

      <div style={{padding:"20px 24px",maxWidth:1100,margin:"0 auto"}}>

        {/* ══ IMPORT ══ */}
        {tab==="import"&&(
          <div style={{maxWidth:520}}>
            <h2 style={{fontWeight:"bold",fontSize:18,margin:"0 0 6px"}}>Rapport importeren</h2>
            <p style={{color:"#6b7280",fontSize:13,margin:"0 0 20px"}}>Exporteer het dagrapport als Excel (.xlsx).</p>
            <div style={{background:"#fff",border:"2px dashed #d1d5db",borderRadius:12,padding:32,textAlign:"center"}}>
              <div style={{fontSize:40,marginBottom:10}}>📂</div>
              <input ref={fileRef} type="file" accept=".xlsx,.xls" onChange={doImport} style={{display:"none"}}/>
              <button onClick={()=>fileRef.current.click()}
                style={{background:"#ea580c",border:"none",color:"#fff",padding:"11px 28px",borderRadius:8,cursor:"pointer",fontFamily:"inherit",fontWeight:"bold",fontSize:14}}>
                📥 Bestand kiezen
              </button>
              {impSt==="laden"&&<div style={{marginTop:14,color:"#9ca3af"}}>Laden...</div>}
              {impSt?.n&&<div style={{marginTop:14,color:"#16a34a",fontWeight:"bold"}}>✓ {impSt.n} kinderen geïmporteerd!</div>}
              {impSt==="leeg"&&<div style={{marginTop:14,color:"#d97706"}}>⚠ Geen kinderen gevonden.</div>}
              {impSt==="fout"&&<div style={{marginTop:14,color:"#dc2626"}}>✕ Kon bestand niet lezen.</div>}
            </div>
            {kids.length>0&&(
              <div style={{marginTop:12,background:"#fff7ed",border:"1px solid #fed7aa",borderRadius:8,padding:12,display:"flex",alignItems:"center",justifyContent:"space-between",fontSize:13}}>
                <span><strong>{kids.length} kinderen</strong> geladen voor {DAYS[dag]}</span>
                <button onClick={()=>setKdPD(p=>({...p,[dag]:[]}))} style={{background:"none",border:"1px solid #d1d5db",borderRadius:5,padding:"3px 10px",cursor:"pointer",color:"#9ca3af",fontSize:12}}>🗑 Wissen</button>
              </div>
            )}
          </div>
        )}

        {/* ══ RITTEN ══ */}
        {tab==="ritten"&&(
          <div>
            {/* Bovenblok */}
            <div style={{background:"#fff",border:"1px solid #e5e7eb",borderRadius:12,padding:16,marginBottom:16}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16}}>

                {/* Bijzonderheden + fietsen */}
                <div>
                  <div style={{fontWeight:"bold",fontSize:11,color:"#6b7280",marginBottom:6,textTransform:"uppercase",letterSpacing:1}}>Bijzonderheden</div>
                  <textarea value={bijz} onChange={e=>setBijz(e.target.value)} placeholder="Bijzonderheden voor vandaag..." rows={3}
                    style={{width:"100%",border:"1px solid #e5e7eb",borderRadius:7,padding:8,fontFamily:"inherit",fontSize:12,resize:"none",boxSizing:"border-box"}}/>
                  <div style={{fontSize:10,color:"#9ca3af",marginTop:3}}>blauw = bus · zwart = lopen · rood = fietsen</div>
                  {(()=>{
                    const fs=[...new Set(kids.filter(k=>["fiets","zelf"].includes(k.vervoer)).map(k=>k.afk))].sort();
                    if(!fs.length)return null;
                    return(
                      <div style={{marginTop:8,border:"1px solid #e5e7eb",borderRadius:7,overflow:"hidden"}}>
                        <div style={{background:"#f9fafb",padding:"4px 10px",fontSize:10,fontWeight:"bold",color:"#6b7280",borderBottom:"1px solid #e5e7eb",textTransform:"uppercase",letterSpacing:1}}>Fietsen neerzetten</div>
                        {fs.map(school=>{
                          const n=kids.filter(k=>["fiets","zelf"].includes(k.vervoer)&&k.afk===school).length;
                          return(
                            <div key={school} style={{display:"flex",alignItems:"center",gap:8,padding:"4px 10px",borderBottom:"1px solid #f3f4f6"}}>
                              <span style={{flex:1,fontSize:12,fontWeight:"bold"}}>{school}</span>
                              <span style={{fontSize:11,color:"#9ca3af"}}>{n}x</span>
                              <input type="number" min={0} max={99} value={fietsen[dag]?.[school]??""} onChange={e=>setFietsen(p=>({...p,[dag]:{...(p[dag]||{}),[school]:e.target.value}}))}
                                placeholder="0" style={{width:44,border:"1px solid #e5e7eb",borderRadius:5,padding:"2px 6px",fontSize:12,fontFamily:"inherit",textAlign:"center"}}/>
                              <span style={{fontSize:10,color:"#6b7280"}}>🚲</span>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>

                {/* Opvang */}
                <div>
                  <div style={{fontWeight:"bold",fontSize:11,color:"#6b7280",marginBottom:6,textTransform:"uppercase",letterSpacing:1}}>Wie werkt er vandaag?</div>
                  {["WL","SL","OL"].map(loc=>{
                    const info=LOCATIES[loc], namen=aanNamen(loc);
                    return(
                      <div key={loc} style={{marginBottom:8}}>
                        <div style={{fontSize:11,fontWeight:"bold",color:"#374151",marginBottom:3}}>
                          {loc==="WL"?"Wit":loc==="SL"?"Grijs":"Groen"} — {loc} ({info.naam})
                          {namen.length>0&&<span style={{color:"#16a34a",marginLeft:6,fontWeight:"normal"}}>✓ {namen.join(", ")}</span>}
                        </div>
                        <div style={{display:"flex",flexWrap:"wrap",gap:3}}>
                          {pers.map(p=>{const aan=isAan(p.id,loc);return(
                            <label key={p.id} style={{display:"flex",alignItems:"center",gap:3,padding:"2px 7px",borderRadius:20,
                              border:"1px solid "+(aan?"#374151":"#e5e7eb"),background:aan?"#f3f4f6":"#fff",
                              cursor:"pointer",fontSize:11,color:aan?"#111827":"#9ca3af",fontWeight:aan?"bold":"normal"}}>
                              <input type="checkbox" checked={aan} onChange={()=>togAan(p.id,loc)} style={{width:10,height:10}}/>
                              {p.naam}
                            </label>
                          );})}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Bussen */}
                <div>
                  <div style={{fontWeight:"bold",fontSize:11,color:"#6b7280",marginBottom:6,textTransform:"uppercase",letterSpacing:1}}>Bussen beschikbaar</div>
                  <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
                    <button onClick={()=>setMaxBus(p=>({...p,[dag]:Math.max(1,(p[dag]??6)-1)}))} style={{width:28,height:28,borderRadius:6,border:"1px solid #e5e7eb",background:"#f9fafb",cursor:"pointer",fontSize:15,fontWeight:"bold"}}>−</button>
                    <div style={{flex:1,textAlign:"center",fontSize:26,fontWeight:"bold",color:"#1e1b4b"}}>{maxB}</div>
                    <button onClick={()=>setMaxBus(p=>({...p,[dag]:Math.min(10,(p[dag]??6)+1)}))} style={{width:28,height:28,borderRadius:6,border:"1px solid #e5e7eb",background:"#f9fafb",cursor:"pointer",fontSize:15,fontWeight:"bold"}}>+</button>
                  </div>
                  <div style={{fontSize:11,color:"#9ca3af",textAlign:"center"}}>{busKids.length} met bus · {ritten.length} ritten</div>

                  {/* PDF Export */}
                  <div style={{marginTop:16,paddingTop:12,borderTop:"1px solid #e5e7eb"}}>
                    <div style={{fontWeight:"bold",fontSize:11,color:"#6b7280",marginBottom:6,textTransform:"uppercase",letterSpacing:1}}>PDF genereren</div>
                    <button onClick={()=>setExportData(exporteerData())}
                      style={{width:"100%",background:"#ea580c",border:"none",color:"#fff",padding:"8px 14px",borderRadius:7,cursor:"pointer",fontFamily:"inherit",fontWeight:"bold",fontSize:12,marginBottom:6}}>
                      📋 Exporteer data voor PDF
                    </button>
                    {exportData&&(
                      <div style={{background:"#f0fdf4",border:"1px solid #16a34a",borderRadius:7,padding:8}}>
                        <div style={{fontSize:10,color:"#15803d",fontWeight:"bold",marginBottom:4}}>✓ Klaar! Kopieer en plak in de chat hieronder:</div>
                        <textarea readOnly rows={3} value={"Maak een PDF van deze rittenlijst en sla op als PDF bestand:\n\n"+exportData}
                          onClick={e=>{e.target.select();try{document.execCommand("copy");alert("✓ Gekopieerd! Plak nu in de Claude chat.");}catch(err){}}}
                          style={{width:"100%",fontSize:9,border:"1px solid #bbf7d0",borderRadius:5,padding:6,fontFamily:"monospace",background:"#fff",boxSizing:"border-box",cursor:"pointer",resize:"none"}}/>
                        <div style={{fontSize:10,color:"#6b7280",marginTop:3}}>👆 Klik op de tekst om te kopiëren</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Rittenlijst */}
            {kids.length===0?(
              <div style={{textAlign:"center",color:"#9ca3af",padding:60,fontSize:15}}>
                Geen kinderen geladen voor {DAYS[dag]}.<br/><span style={{fontSize:12}}>Ga naar Import.</span>
              </div>
            ):(
              <div>
                {/* Bussen */}
                {ritten.map(rit=>{
                  const c=getChauf(rit.id), bz=bezet(rit.id);
                  return(
                    <div key={rit.id} style={{background:"#fff",border:"2px solid "+rit.kleur,borderRadius:10,overflow:"hidden",marginBottom:8}}>
                      <div style={{background:rit.kleur,color:"#fff",padding:"9px 14px",display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:6}}>
                        <div>
                          <span style={{fontWeight:"bold",fontSize:14}}>🚐 {rit.label}</span>
                          {rit.samengevoegdLabel&&<span style={{fontSize:10,marginLeft:8,opacity:0.85,fontStyle:"italic"}}>+ {rit.samengevoegdLabel}</span>}
                          {rit.opmerking&&<div style={{fontSize:10,opacity:0.85,fontStyle:"italic",marginTop:1}}>{rit.opmerking}</div>}
                        </div>
                        <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                          <select value={chauf[dag]?.[rit.id]||""} onChange={e=>setChaufId(rit.id,e.target.value?Number(e.target.value):null)}
                            style={{fontSize:12,border:"none",borderRadius:5,padding:"2px 6px",fontFamily:"inherit",background:"rgba(255,255,255,0.9)",color:"#111827"}}>
                            <option value="">— Chauffeur —</option>
                            {beschikbaar.map(p=><option key={p.id} value={p.id} disabled={bz.has(p.id)}>{p.naam}{bz.has(p.id)?" ✗":""}</option>)}
                          </select>
                          {c&&<span style={{fontSize:11,fontWeight:"bold",background:"rgba(255,255,255,0.2)",borderRadius:4,padding:"1px 6px"}}>✓ {c.naam}</span>}
                          <select onChange={e=>{if(!e.target.value)return;voegSamen(rit.id,e.target.value);e.target.value="";}} defaultValue=""
                            style={{fontSize:10,border:"none",borderRadius:4,padding:"1px 4px",fontFamily:"inherit",background:"rgba(255,255,255,0.9)",color:"#111827"}}>
                            <option value="">⊕ Samenvoegen</option>
                            {rittenRaw.filter(r=>r.id!==rit.id&&!(samen[dag]||{})[r.id]).map(r=><option key={r.id} value={r.id}>{r.label}</option>)}
                          </select>
                          {(samen[dag]||{})[rit.id]&&<button onClick={()=>maakLosSamen(rit.id)} style={{background:"rgba(255,255,255,0.15)",border:"none",color:"#fff",borderRadius:4,padding:"1px 6px",cursor:"pointer",fontSize:10}}>✕ los</button>}
                          <span style={{background:"rgba(0,0,0,0.2)",borderRadius:20,padding:"1px 8px",fontSize:11,fontWeight:"bold"}}>{rit.kinderen.length}/{BUS_CAP}</span>
                        </div>
                      </div>
                      <div style={{padding:"10px 14px",display:"flex",flexDirection:"column",gap:8}}>
                        {rit.stops.map((stop,si)=>(
                          <div key={si} style={{display:"flex",gap:10,alignItems:"flex-start"}}>
                            <div style={{flexShrink:0,minWidth:120}}>
                              <span style={{background:rit.kleur,color:"#fff",borderRadius:4,padding:"2px 8px",fontSize:11,fontWeight:"bold"}}>{stop.tijd}</span>
                              <div style={{fontSize:12,fontWeight:"bold",color:"#374151",marginTop:2}}>{stop.scholen.join(" + ")}</div>
                              <div style={{fontSize:10,color:"#9ca3af"}}>{stop.kids.length} kinderen</div>
                            </div>
                            <div style={{display:"flex",flexWrap:"wrap",gap:4,flex:1}}>
                              {stop.kids.map(k=><KindBadge key={k.id} k={k}/>)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}

                {/* Lopers */}
                {groepen.filter(g=>g.type==="lopen").length>0&&(
                  <div>
                    <div style={{fontSize:11,fontWeight:"bold",color:"#111827",margin:"10px 0 5px",textTransform:"uppercase",letterSpacing:1}}>🚶 Lopers</div>
                    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:8,marginBottom:8}}>
                      {groepen.filter(g=>g.type==="lopen").map(gr=>{
                        const b1=getBegel(gr.id),b2v=getBegel2(gr.id);
                        return(
                          <div key={gr.id} style={{background:"#fff",border:"2px solid #111827",borderRadius:10,overflow:"hidden"}}>
                            <div style={{background:"#111827",color:"#fff",padding:"8px 12px",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                              <div>
                                <span style={{fontWeight:"bold",fontSize:13}}>🚶 {gr.label}</span>
                                {gr.opmerking&&<div style={{fontSize:10,opacity:0.85,fontStyle:"italic",marginTop:1}}>{gr.opmerking}</div>}
                              </div>
                              <span style={{background:"rgba(0,0,0,0.2)",borderRadius:20,padding:"1px 7px",fontSize:11,flexShrink:0}}>{gr.kids.length}x</span>
                            </div>
                            <div style={{padding:"6px 10px",background:"#f9fafb",borderBottom:"1px solid #e5e7eb",display:"flex",gap:6,flexWrap:"wrap"}}>
                              <div style={{display:"flex",alignItems:"center",gap:4,flex:1,minWidth:120}}>
                                <span style={{fontSize:10,fontWeight:"bold",color:"#9ca3af",flexShrink:0}}>Begel.</span>
                                <select value={begel[dag]?.[gr.id]||""} onChange={e=>setBegelId(gr.id,e.target.value?Number(e.target.value):null)}
                                  style={{flex:1,fontSize:11,border:"1px solid #e5e7eb",borderRadius:4,padding:"2px 4px",fontFamily:"inherit",background:"#fff"}}>
                                  <option value="">— Kies —</option>
                                  {beschikbaar.map(p=><option key={p.id} value={p.id} disabled={bz1(gr.id).has(p.id)}>{p.naam}</option>)}
                                </select>
                                {b1&&<span style={{fontSize:10,color:"#16a34a",fontWeight:"bold",flexShrink:0}}>✓{b1.naam}</span>}
                              </div>
                              <div style={{display:"flex",alignItems:"center",gap:4,flex:1,minWidth:120}}>
                                <span style={{fontSize:10,fontWeight:"bold",color:"#9ca3af",flexShrink:0}}>2e</span>
                                <select value={begel2[dag]?.[gr.id]||""} onChange={e=>setBegelId2(gr.id,e.target.value?Number(e.target.value):null)}
                                  style={{flex:1,fontSize:11,border:"1px solid #e5e7eb",borderRadius:4,padding:"2px 4px",fontFamily:"inherit",background:"#fff"}}>
                                  <option value="">— Optioneel —</option>
                                  {beschikbaar.map(p=><option key={p.id} value={p.id} disabled={bz2(gr.id).has(p.id)}>{p.naam}</option>)}
                                </select>
                                {b2v&&<span style={{fontSize:10,color:"#16a34a",fontWeight:"bold",flexShrink:0}}>✓{b2v.naam}</span>}
                              </div>
                            </div>
                            <div style={{padding:"8px 12px"}}>
                              {[...new Set(gr.kids.map(k=>k.tijd))].sort().map(tijd=>(
                                <div key={tijd} style={{marginBottom:4}}>
                                  <div style={{fontSize:10,fontWeight:"bold",color:"#9ca3af",marginBottom:3}}>{tijd}</div>
                                  <div style={{display:"flex",flexWrap:"wrap",gap:3}}>
                                    {gr.kids.filter(k=>k.tijd===tijd).map(k=>{
                                      const L=LOCATIES[k.loc];
                                      return(
                                        <div key={k.id} style={{display:"inline-flex",alignItems:"center",gap:3,background:L?.kleur,color:L?.tekstKleur,border:"1px solid "+(L?.border||"#ccc"),borderRadius:5,padding:"2px 7px",fontSize:12,fontWeight:"bold"}}>
                                          {kortNaam(k.naam)}<span style={{fontSize:9,opacity:0.7,fontWeight:"normal"}}>{k.loc}</span>
                                          <button onClick={()=>setV(k.id,"bus")} style={{background:"rgba(0,0,0,0.2)",border:"none",color:"inherit",borderRadius:3,padding:"0 4px",cursor:"pointer",fontSize:9}}>🚐</button>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Fietsers */}
                {groepen.filter(g=>g.type==="fiets").length>0&&(
                  <div>
                    <div style={{fontSize:11,fontWeight:"bold",color:"#dc2626",margin:"10px 0 5px",textTransform:"uppercase",letterSpacing:1}}>🚲 Fietsers</div>
                    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:8,marginBottom:8}}>
                      {groepen.filter(g=>g.type==="fiets").map(gr=>{
                        const b1=getBegel(gr.id);
                        return(
                          <div key={gr.id} style={{background:"#fff",border:"2px solid #dc2626",borderRadius:10,overflow:"hidden"}}>
                            <div style={{background:"#dc2626",color:"#fff",padding:"8px 12px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                              <span style={{fontWeight:"bold",fontSize:13}}>🚲 {gr.label}</span>
                              <span style={{background:"rgba(0,0,0,0.2)",borderRadius:20,padding:"1px 7px",fontSize:11}}>{gr.kids.length}x</span>
                            </div>
                            <div style={{padding:"6px 10px",background:"#f9fafb",borderBottom:"1px solid #e5e7eb",display:"flex",alignItems:"center",gap:4}}>
                              <span style={{fontSize:10,fontWeight:"bold",color:"#9ca3af",flexShrink:0}}>Begeleider</span>
                              <select value={begel[dag]?.[gr.id]||""} onChange={e=>setBegelId(gr.id,e.target.value?Number(e.target.value):null)}
                                style={{flex:1,fontSize:11,border:"1px solid #e5e7eb",borderRadius:4,padding:"2px 4px",fontFamily:"inherit",background:"#fff"}}>
                                <option value="">— Kies —</option>
                                {beschikbaar.map(p=><option key={p.id} value={p.id} disabled={bz1(gr.id).has(p.id)}>{p.naam}</option>)}
                              </select>
                              {b1&&<span style={{fontSize:10,color:"#16a34a",fontWeight:"bold",flexShrink:0}}>✓ {b1.naam}</span>}
                            </div>
                            <div style={{padding:"8px 12px"}}>
                              {[...new Set(gr.kids.map(k=>k.tijd))].sort().map(tijd=>(
                                <div key={tijd} style={{marginBottom:4}}>
                                  <div style={{fontSize:10,fontWeight:"bold",color:"#9ca3af",marginBottom:3}}>{tijd}</div>
                                  <div style={{display:"flex",flexWrap:"wrap",gap:3}}>
                                    {gr.kids.filter(k=>k.tijd===tijd).map(k=>{
                                      const L=LOCATIES[k.loc];
                                      return(
                                        <div key={k.id} style={{display:"inline-flex",alignItems:"center",gap:3,background:k.vervoer==="zelf"?"#6b7280":L?.kleur,color:k.vervoer==="zelf"?"#fff":L?.tekstKleur,border:"1px solid "+(L?.border||"#ccc"),borderRadius:5,padding:"2px 7px",fontSize:12,fontWeight:"bold"}}>
                                          {kortNaam(k.naam)}
                                          {k.vervoer==="zelf"&&<span style={{fontSize:9,opacity:0.8}}>(Z)</span>}
                                          <span style={{fontSize:9,opacity:0.7,fontWeight:"normal"}}>{k.loc}</span>
                                          <button onClick={()=>setV(k.id,k.vervoer==="zelf"?"fiets":"zelf")} style={{background:"rgba(0,0,0,0.2)",border:"none",color:"inherit",borderRadius:3,padding:"0 3px",cursor:"pointer",fontSize:9}}>{k.vervoer==="zelf"?"↩":"Z"}</button>
                                          <button onClick={()=>setV(k.id,"bus")} style={{background:"rgba(0,0,0,0.2)",border:"none",color:"inherit",borderRadius:3,padding:"0 3px",cursor:"pointer",fontSize:9}}>🚐</button>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Activiteiten op rittenlijst */}
                {activiteiten.length>0&&(
                  <div style={{background:"#fff",border:"1px solid #e5e7eb",borderRadius:12,overflow:"hidden",marginBottom:8}}>
                    <div style={{background:"#374151",color:"#fff",padding:"10px 16px",fontWeight:"bold",fontSize:14}}>⚽ Activiteiten — {DAYS[dag]}</div>
                    {activiteiten.map(act=>{
                      const brId=actBegel[dag]?.["brenger_"+act.id];
                      const brenger=brId&&brId!=="zelf"?pers.find(p=>p.id===Number(brId))||null:null;
                      const isZelf=brId==="zelf";
                      return(
                        <div key={act.id} style={{display:"grid",gridTemplateColumns:"110px 90px 1fr 180px",gap:10,padding:"8px 16px",borderTop:"1px solid #f3f4f6",alignItems:"start",fontSize:12}}>
                          <div><div style={{fontWeight:"bold",color:"#111827"}}>{act.naam}</div><div style={{color:"#9ca3af",fontSize:10}}>{act.locatie}</div></div>
                          <div><div style={{fontWeight:"bold",color:"#374151"}}>↗ {act.vertrek}</div>{act.start&&<div style={{color:"#9ca3af",fontSize:10}}>{act.start}{act.eind?"–"+act.eind:""}</div>}</div>
                          <div style={{color:"#6b7280"}}>{act.kinderen.split(",").map(n=>kortNaam(n.trim())).join(", ")}{act.opmerking&&<div style={{fontSize:10,color:"#9ca3af",fontStyle:"italic",marginTop:2}}>{act.opmerking}</div>}</div>
                          <div>
                            <select value={brId||""} onChange={e=>setActBegel(p=>({...p,[dag]:{...(p[dag]||{}),["brenger_"+act.id]:e.target.value||null}}))}
                              style={{fontSize:11,border:"1px solid #e5e7eb",borderRadius:5,padding:"3px 6px",fontFamily:"inherit",background:"#fff",width:"100%",marginBottom:2}}>
                              <option value="">— Wie brengt? —</option>
                              <option value="zelf">✌ Zelfstandig</option>
                              {beschikbaar.map(p=><option key={p.id} value={p.id}>{p.naam}</option>)}
                            </select>
                            {isZelf&&<span style={{fontSize:11,color:"#7c3aed",fontWeight:"bold"}}>✌ Zelfstandig</span>}
                            {brenger&&<span style={{fontSize:11,color:"#16a34a",fontWeight:"bold"}}>✓ {brenger.naam}</span>}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ══ ACTIVITEITEN ══ */}
        {tab==="activiteiten"&&(
          <div>
            <h2 style={{fontWeight:"bold",fontSize:18,margin:"0 0 4px"}}>Activiteiten</h2>
            <p style={{color:"#6b7280",fontSize:13,margin:"0 0 16px"}}>Vaste sportactiviteiten — stel eenmalig in, wijs per dag een brenger toe op de rittenlijst.</p>
            <div style={{background:"#fff",border:"1px solid #e5e7eb",borderRadius:12,overflow:"hidden",marginBottom:16}}>
              <div style={{background:"#374151",color:"#fff",padding:"10px 16px",fontWeight:"bold",fontSize:14,display:"flex",justifyContent:"space-between"}}>
                <span>Alle activiteiten</span>
                <span style={{background:"rgba(255,255,255,0.15)",borderRadius:20,padding:"1px 9px",fontSize:12}}>{activiteiten.length}</span>
              </div>
              {activiteiten.map((act,i)=>(
                <div key={act.id} style={{borderTop:i>0?"1px solid #f3f4f6":"none",padding:"10px 16px"}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr auto",gap:8,alignItems:"start"}}>
                    <div>
                      <div style={{fontWeight:"bold",fontSize:13}}>{act.naam}</div>
                      <div style={{fontSize:11,color:"#6b7280"}}>{act.locatie}</div>
                      {act.opmerking&&<div style={{fontSize:10,color:"#9ca3af",fontStyle:"italic",marginTop:2}}>{act.opmerking}</div>}
                    </div>
                    <div style={{fontSize:12,color:"#374151"}}>
                      <div>↗ {act.vertrek}</div>
                      {act.start&&<div>{act.start}{act.eind?" – "+act.eind:""}</div>}
                    </div>
                    <div style={{fontSize:12}}>{act.kinderen.split(",").map(n=>kortNaam(n.trim())).join(", ")}</div>
                    <button onClick={()=>setAct(p=>p.filter(a=>a.id!==act.id))}
                      style={{background:"none",border:"1px solid #e5e7eb",color:"#d1d5db",borderRadius:5,padding:"4px 8px",cursor:"pointer",fontSize:12}}>✕</button>
                  </div>
                </div>
              ))}
            </div>
            <div style={{background:"#fff",border:"1px solid #e5e7eb",borderRadius:12,padding:16}}>
              <div style={{fontWeight:"bold",fontSize:12,color:"#9ca3af",marginBottom:12,letterSpacing:1}}>ACTIVITEIT TOEVOEGEN</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:8}}>
                {[["naam","Naam"],["locatie","Locatie"],["vertrek","Vertrek"],["start","Start"],["eind","Eind"]].map(([k,ph])=>(
                  <input key={k} placeholder={ph} value={nieuweAct[k]} onChange={e=>setNieuweAct(p=>({...p,[k]:e.target.value}))}
                    style={{border:"1px solid #e5e7eb",borderRadius:6,padding:"6px 10px",fontFamily:"inherit",fontSize:13}}/>
                ))}
              </div>
              <textarea placeholder="Kinderen (namen, komma-gescheiden)" value={nieuweAct.kinderen} onChange={e=>setNieuweAct(p=>({...p,kinderen:e.target.value}))} rows={2}
                style={{width:"100%",border:"1px solid #e5e7eb",borderRadius:6,padding:"6px 10px",fontFamily:"inherit",fontSize:13,resize:"vertical",boxSizing:"border-box",marginBottom:8}}/>
              <input placeholder="Opmerking" value={nieuweAct.opmerking} onChange={e=>setNieuweAct(p=>({...p,opmerking:e.target.value}))}
                style={{width:"100%",border:"1px solid #e5e7eb",borderRadius:6,padding:"6px 10px",fontFamily:"inherit",fontSize:13,marginBottom:8,boxSizing:"border-box"}}/>
              <button onClick={()=>{if(!nieuweAct.naam.trim())return;setAct(p=>[...p,{...nieuweAct,id:Date.now()}]);setNieuweAct({naam:"",locatie:"",vertrek:"",start:"",eind:"",kinderen:"",opmerking:""}); }}
                style={{background:"#1e1b4b",border:"none",color:"#fff",padding:"8px 20px",borderRadius:7,cursor:"pointer",fontFamily:"inherit",fontWeight:"bold",fontSize:13}}>+ Toevoegen</button>
            </div>
          </div>
        )}

        {/* ══ PERSONEEL ══ */}
        {tab==="personeel"&&(
          <div style={{maxWidth:460}}>
            <h2 style={{fontWeight:"bold",fontSize:18,margin:"0 0 6px"}}>Personeel</h2>
            <div style={{background:"#fff",border:"1px solid #e5e7eb",borderRadius:10,padding:16,marginBottom:16}}>
              <div style={{fontSize:11,fontWeight:"bold",color:"#9ca3af",marginBottom:10,letterSpacing:1}}>TOEVOEGEN</div>
              <div style={{display:"flex",gap:8}}>
                <input placeholder="Naam medewerker" value={nieuweNaam} onChange={e=>setNN(e.target.value)}
                  onKeyDown={e=>{if(e.key==="Enter"&&nieuweNaam.trim()){setPers(p=>[...p,{id:Date.now(),naam:nieuweNaam.trim()}]);setNN("");}}}
                  style={{flex:1,border:"1px solid #e5e7eb",borderRadius:7,padding:"8px 12px",fontFamily:"inherit",fontSize:13}}/>
                <button onClick={()=>{if(!nieuweNaam.trim())return;setPers(p=>[...p,{id:Date.now(),naam:nieuweNaam.trim()}]);setNN("");}}
                  style={{background:"#ea580c",border:"none",color:"#fff",padding:"8px 18px",borderRadius:7,cursor:"pointer",fontFamily:"inherit",fontWeight:"bold",fontSize:16}}>+</button>
              </div>
            </div>
            <div style={{background:"#fff",border:"1px solid #e5e7eb",borderRadius:10,overflow:"hidden"}}>
              <div style={{background:"#1e1b4b",color:"#fff",padding:"10px 16px",fontWeight:"bold",fontSize:14,display:"flex",justifyContent:"space-between"}}>
                <span>Medewerkers</span>
                <span style={{background:"rgba(255,255,255,0.15)",borderRadius:20,padding:"1px 9px",fontSize:12}}>{pers.length}</span>
              </div>
              {pers.map((p,i)=>(
                <div key={p.id} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 16px",borderTop:i>0?"1px solid #f3f4f6":"none"}}>
                  <div style={{display:"flex",alignItems:"center",gap:10}}>
                    <div style={{width:32,height:32,background:"#f3f4f6",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:13,color:"#374151"}}>{p.naam[0]}</div>
                    <span style={{fontWeight:"bold",fontSize:14}}>{p.naam}</span>
                  </div>
                  <button onClick={()=>setPers(prev=>prev.filter(x=>x.id!==p.id))}
                    style={{background:"none",border:"1px solid #e5e7eb",color:"#d1d5db",borderRadius:5,padding:"3px 9px",cursor:"pointer",fontSize:13}}>✕</button>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
